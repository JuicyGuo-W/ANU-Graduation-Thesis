import warnings
warnings.filterwarnings('ignore')
from implementation.classifiers import *
from implementation.main_process import *
"""
    winequality-white dataset from UCI Resposiry
    Shape: (4898,11) 
    classes: quality: [3, 4, 5, 6, 7, 8, 9](Drop classes 9 because it's too small.)
6    2198
5    1457
7     880
8     175
4     163
3      20
9       5

Hence,
     Shape: (4893,11) 
    classes: quality: [3, 4, 5, 6, 7, 8].
6    2198
5    1457
7     880
8     175
4     163
3      20
"""


def preprocessing_df():
    df = pd.read_csv("./datasets/winequality-white.csv", sep=';')
    # remove blanks
    df.dropna()
    # remove unknown
    for i in range(df.shape[1]): df = df[~df.iloc[:, i].isin([" ?"])]
    # drop classes 9
    df = df.drop(df[(df['quality'] == 9)].index)
    # print(list(set(list(df_ready.quality))))
    return df

# preparations
t = 10
sample_sizes = [500,1000,3000,4800]
df = preprocessing_df()

# call for test process
result_dic = main(df,sample_sizes,t)

# call for plot
name = "Winequality_white"
plot_results(result_dic,name)