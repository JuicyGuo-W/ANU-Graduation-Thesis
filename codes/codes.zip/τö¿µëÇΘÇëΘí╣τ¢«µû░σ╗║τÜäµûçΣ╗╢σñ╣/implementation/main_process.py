import numpy as np

from implementation.classifiers import *
from implementation.metrics import *
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings('ignore')


def main(df, sample_sizes, t):
    global test_all_prob, clf_classes
    result_dic = {}
    test_prior_probs = compute_prior_probs(df.iloc[:, -1])  # the whole dataset's
    # print(test_prior_probs)
    briers = []
    mses = []
    birs = []
    accs = []
    cals = []
    rocs = []
    exp_values = []
    # print(df.shape)

    print("measure_names: [brier score,mse,BIR,ACC,Calibration,ROC_AOC]")
    print("classifier_names: [prior knowledge, NB, LR, DT, RF, SVM]")
    for sample_size in sample_sizes:
        # for each sample size
        samples = sample_size
        flag = 0
        means_matrix_per_size = []  # measures by classifiers: 6*6
        stds_matrix_per_size = []
        while flag <= 5:
            # for each classifier
            for i in range(t):
                # for each time
                X_train, y_train, X_test, y_test = split(test_prior_probs, df, samples, 0.2)
                # print(y_test.shape)

                # implementation
                y_pred_test = None
                test_prob = None

                if flag == 0:
                    y_pred_test, test_prob, test_all_prob, clf_classes = prior_knowledge(test_prior_probs,
                                                                                         X_test)  # without training
                elif flag == 1:
                    y_pred_train, y_pred_test, train_prob, test_prob, test_all_prob, clf_classes = naive_bayes(X_train,
                                                                                                               y_train,
                                                                                                               X_test)
                elif flag == 2:
                    y_pred_train, y_pred_test, train_prob, test_prob, test_all_prob, clf_classes = logistic_regression(
                        X_train, y_train, X_test)
                elif flag == 3:
                    y_pred_train, y_pred_test, train_prob, test_prob, test_all_prob, clf_classes = decision_tree(
                        X_train, y_train, X_test)
                elif flag == 4:
                    y_pred_train, y_pred_test, train_prob, test_prob, test_all_prob, clf_classes = random_forest(
                        X_train, y_train, X_test)
                elif flag == 5:
                    y_pred_train, y_pred_test, train_prob, test_prob, test_all_prob, clf_classes = svm(X_train, y_train,
                                                                                                       X_test)
                #  preprocessing for ann, including making labels numerics from 0
                #  y_pred_test, test_prob,test_all_prob ,clf_classes= ann(X_train,y_train_ann, X_test, y_test_ann)
                #  recovery...

                y_test_ohe = pd.get_dummies(y_test) # to form a matrix: ?
                # class_list = le.classes_
                # print("list", class_list)
                # print(y_pred_all)

                # assessment
                brier_score = brier(y_test_ohe, test_all_prob)
                mse_loss = mse(y_test, y_pred_test)
                # print(type(test_prob))
                bir_score = bayesian_IR(y_pred_test, test_prior_probs, y_test, test_prob)
                acc, cal = acc_calibration(y_test, y_pred_test, test_prob)
                roc_auc_score = roc_auc(y_test_ohe, test_all_prob, clf_classes)
                # exp_value = expected_value(y_test_le, y_pred_test_le)

                # record
                birs.append(brier_score)
                mses.append(mse_loss)
                briers.append(bir_score)
                accs.append(acc)
                cals.append(cal)
                rocs.append(roc_auc_score)
                # exp_values.append(exp_value)

            # print results for each classifier
            classifier_names = ['prior knowledge', 'NB', 'LR', 'DT', 'RF', 'SVM']

            brier_mean, brier_me = compute_confidence_interval(briers)
            mse_mean, mse_me = compute_confidence_interval(mses)
            bir_mean, bir_me = compute_confidence_interval(birs)
            acc_mean, acc_me = compute_confidence_interval(accs)
            cal_mean, cal_me = compute_confidence_interval(cals)
            roc_mean, roc_me = compute_confidence_interval(rocs)
            # ev_mean, ev_me = compute_confidence_interval(exp_values)

            # print("\nAfter " + str(t) + " times of " + str(samples) + " samples" + " of " + str(classifier_names[flag]))
            # print("Brier Score: ", briers)
            # print("CI: "+str(brier_mean)+" +- "+str(brier_me)+"\n")
            # print("MSE loss: ", mses)
            # print("CI: "+str(mse_mean)+" +- "+str(mse_me)+"\n")
            # print("Bayesian IR: ", birs)
            # print("CI: "+str(bir_mean)+" +- "+str(bir_me)+"\n")
            # print("Accuracy: ", accs)
            # print("CI: "+str(acc_mean)+" +- "+str(acc_me)+"\n")
            # print("Calibration: ", cals)
            # print("CI: "+str(cal_mean)+" +- "+str(cal_me)+"\n")
            # print("ROC_AUC: ", rocs)
            # print("CI: "+str(roc_mean)+" +- "+str(roc_me)+"\n")
            # # print("expected value: ", exp_values)
            # print("CI: "+str(ev_mean)+" +- "+str(ev_me)+"\n")

            means = [brier_mean, mse_mean, bir_mean, acc_mean, cal_mean, roc_mean]
            stds = [brier_me, mse_me, bir_me, acc_me, cal_me, roc_me]
            # print("means:",means)
            # print("stds:",stds)
            means_matrix_per_size.append(means)
            stds_matrix_per_size.append(stds)

            # end of each classifier
            flag += 1

        #  record results for each sample size
        means_matrix_per_size = np.array(means_matrix_per_size).T.tolist()
        stds_matrix_per_size = np.array(stds_matrix_per_size).T.tolist()
        print("\n" + str(samples) + " measures by classifiers:")
        print("means_" + str(samples) + " = " + str(means_matrix_per_size))
        print("stds_" + str(samples) + " = " + str(list(stds_matrix_per_size)))

        result_dic[str(samples)] = (np.array(means_matrix_per_size),np.array(stds_matrix_per_size))

    return result_dic

def plot_results(result_dic,name):
    # plots
    y_labels = ['Brier Score(the less the better)', 'MSE', 'BIR(the more the better)', 'ACC',
                'Calibration(the less the better)', 'ROC_AOC']
    fig = plt.figure(figsize=(23, 16))
    for t in range(6):
        mean = []
        errors = []
        for i in range(6):
            means_sizes_list = []
            stds_sizes_list = []
            [means_sizes_list.append(value[0][t][i]) for value in result_dic.values()]
            [stds_sizes_list.append(value[1][t][i]) for value in result_dic.values()]
            mean.append(means_sizes_list)
            errors.append(stds_sizes_list)
        # print(mean)
        # print(errors)

        # plot

        ax1 = fig.add_subplot(int("32" + str(t + 1)))
        x_ticks = list(result_dic.keys())

        x_Prior = np.arange(1, int(len(result_dic.keys()))+1)
        x_NB = x_Prior + 0.1
        x_LR = x_NB + 0.1
        x_DT = x_LR + 0.1
        x_RF = x_DT + 0.1
        x_SVM = x_RF + 0.1

        # plot
        ax1.errorbar(x=x_Prior, y=mean[0], yerr=errors[0], fmt='', capsize=1,
                     linestyle="-.", linewidth=0.5, elinewidth=1.5,
                     marker="o", ms=2, label="Prior Knowledge")

        ax1.errorbar(x=x_NB, y=mean[1], yerr=errors[1], fmt='', capsize=1,
                     linestyle="-.", linewidth=0.5, elinewidth=1.5,
                     marker="o", ms=2, label="Naive Bayes")
        ax1.errorbar(x=x_LR, y=mean[2], yerr=errors[2], fmt='', capsize=1,
                     linestyle="-.", linewidth=0.5, elinewidth=1.5,
                     marker="o", ms=2, label="Linear Regression")
        ax1.errorbar(x=x_DT, y=mean[3], yerr=errors[3], fmt='', capsize=1,
                     linestyle="-.", linewidth=0.5, elinewidth=1.5,
                     marker="o", ms=2, label="Decision Tree")
        ax1.errorbar(x=x_RF, y=mean[4], yerr=errors[4], fmt='', capsize=1,
                     linestyle="-.", linewidth=0.5, elinewidth=1.5,
                     marker="o", ms=2, label="Random Forest")
        ax1.errorbar(x=x_SVM, y=mean[5], yerr=errors[5], fmt='', capsize=1,
                     linestyle="-.", linewidth=0.5, elinewidth=1.5,
                     marker="o", ms=2, label="SVM", color="black")

        plt.xticks(x_DT, x_ticks, rotation=90)
        plt.xlabel('Data Instances (with 95% confidence )')
        plt.ylabel(y_labels[t])
        plt.legend()

    # lines, labels = fig.axes[-1].get_legend_handles_labels()
    # fig.legend(lines, labels)
    # fig.legend()

    plt.suptitle('Results for '+name+' Data set', fontsize="xx-large")
    plt.tight_layout()
    plt.savefig('./test1.jpg')
    plt.show()


