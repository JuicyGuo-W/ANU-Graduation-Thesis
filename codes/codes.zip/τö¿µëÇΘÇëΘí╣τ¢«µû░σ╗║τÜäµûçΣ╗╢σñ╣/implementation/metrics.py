import numpy as np
from sklearn.metrics import *
import math


'''
measures
Predictive Accuracy and Calibration
AUC-ROC
Mean Squared Error
Brier Score
(KLD)
BIR
Cumulative/Average Expected Value

the less the better: brier score, calibration, MSE
the more the better: BIR, Accuracy, AUC_ROC
'''

def compute_confidence_interval(scores): # 95%, get a sample of 5, get the mean and me
    n = len(scores)
    mean = np.mean(scores)
    std = np.std(scores)
    z = 1.96
    margin_of_error = z*std/math.sqrt(n)
    # np.random.seed(10) # set the random seed
    # sample_size = 5  # get s sample of 5 out of 10
    # sample = np.random.choice(a=scores, size=sample_size)  # from scores
    # sample_mean = sample.mean()  # the mean of samples
    # z_critical = stats.norm.ppf(q=0.975)  # Get the z-critical value* (two-tail) # 1.959963984540054
    # sample_std = np.std(sample)  # Get the population standard deviation
    # margin_of_error = z_critical * (sample_std / math.sqrt(sample_size))  # get the standard error
    return mean,margin_of_error

def brier(y_true_ohe, y_prob_all):  # the less the better
    brier_score = np.mean(np.sum((y_prob_all - y_true_ohe) ** 2, axis=1))
    # brier_score = brier_score_loss(y_true_le, y_prob)
    return brier_score


def bayesian_IR(y_pred, prior_probs, y_true, post_probs):
    score = 0.0
    y_true = y_true.tolist()
    for i in range(len(y_true)):
        prior_prob = prior_probs[y_true[i]]
        post_prob = post_probs[i]
        if y_true[i] == y_pred[i]:
            score += math.log(post_prob) / math.log(prior_prob)
        else:
            score += math.log(1 - post_prob) / math.log(1 - prior_prob)
    score /= len(y_true)
    return score


def mse(y_true, y_pred):
    # print("pred",y_pred.shape)
    # print('true:',y_true.shape)
    mse_loss = mean_squared_error(y_true, y_pred)
    return mse_loss


def acc_calibration(y_true, y_pred, post_prob):
    acc = accuracy_score(y_true, y_pred)
    y_true = y_true.tolist()
    cal_sum = 0.0
    for i in range(len(y_true)):
        if y_true[i] == y_pred[i]:
            cal_sum += math.pow((1 - post_prob[i]), 2)
        else:
            cal_sum += math.pow(post_prob[i], 2)
    cal = math.sqrt(cal_sum / len(y_true))  # the less the better
    return acc, cal


def roc_auc(y_true_ohe, y_prob_all,clf_classes):
    score = roc_auc_score(y_true_ohe, y_prob_all, multi_class='ovr',labels = clf_classes)
    return score


# def expected_value(y_true,y_pred):
#     matrix = np.array([[1, 0.6],[0.1, 1]])
#     cm = confusion_matrix(y_true,y_pred)
#     score = np.sum(matrix*cm)
#     return score

# confusion matrix
#???