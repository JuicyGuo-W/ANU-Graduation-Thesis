import numpy as np
from sklearn.naive_bayes import BernoulliNB
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
import pandas as pd


def split(priors, data, samples, test_size=0.2):  # as rates
    # get train and test
    data = data.sample(frac=1).reset_index(drop=True)
    test = pd.DataFrame()  # empty dataframes
    train = pd.DataFrame()
    train_priors_array = np.floor(np.array(priors).reshape(priors.shape[0], ) * samples)
    test_priors_array = np.floor(np.array(priors).reshape(priors.shape[0], ) * samples * test_size)
    train_priors_array[0] = samples - np.sum(train_priors_array[1:])  # modification by the most
    test_priors_array[0] = int(test_size * samples) - np.sum(test_priors_array[1:])  # modification by the most
    i = 0
    for col in priors.index:  # for each class
        class_slice = data.loc[data.iloc[:, -1] == col]  # get data slice by proportion
        train_slice = class_slice.iloc[:int(train_priors_array[i]), :]
        test_slice = class_slice.iloc[
                     int(train_priors_array[i]):int(train_priors_array[i]) + max(1, int(test_priors_array[i])),
                     :]  # at least one and ensure the non-redundancy
        train = pd.concat([train, train_slice])  # added to train set and test set separately
        test = pd.concat([test, test_slice])
        i += 1
    train = train.sample(frac=1).reset_index(drop=True)  # shuffle data set
    test = test.sample(frac=1).reset_index(drop=True)
    # print("test",test.shape)
    # print(train)

    # print("shape:",data.shape[1])
    # assert train.shape == (samples,data.shape[1]) ( we can't check, we can +1 or not +1)
    # assert test.shape == (int(test_size * samples),data.shape[1])

    X_train = train.iloc[:, :-1]
    y_train = train.iloc[:, -1]
    X_test = test.iloc[:, :-1]
    y_test = test.iloc[:, -1]

    # print("test value:",y_test.value_counts().shape[0])
    # print("train value:", y_train.value_counts().shape[0])
    assert y_train.value_counts().shape[0] == y_test.value_counts().shape[0]
    # print(X_test.shape)

    return X_train, y_train, X_test, y_test


def smoothing(probs, alpha=1):  # array or matrix; Laplace smoothing
    n = probs.shape[0]
    probs = probs.reshape(n, -1)
    m = probs.shape[1]
    if m == 1:
        probs = probs.reshape(-1, 1)
        sm_probs = np.zeros(n)
        for i in range(n):
            sm_probs[i] = n * probs[i] / (n + alpha)
    else:
        sm_probs = np.copy(probs)
        for i in range(n):
            for j in range(m):
                sm_probs[i][j] = n * probs[i][j] / (n + m * alpha)
    return sm_probs


'''
classifiers
Prior Knowledge
Logistic Regression
SVM
Naive Bayes
Decision Tree
Random Forests
(Ann)
'''


# compute prior probs
def compute_prior_probs(y_true):
    priors = y_true.value_counts(normalize=True)  # use priors with le.classes_ ,such as priors['<=50K']
    return priors


def prior_knowledge(priors, X_test):
    majority_class = priors.index[0]
    # print(majority_class)
    y_pred_test = np.repeat(majority_class, X_test.shape[0])
    priors_sort = priors.sort_index()
    test_all_prob = np.repeat([np.array(priors_sort)], X_test.shape[0], 0)
    # print(test_all_prob.shape)
    test_prob = np.repeat(priors[majority_class], X_test.shape[0])
    # print(test_prob)
    clf_classes = list(priors_sort.index)
    # print(clf_classes)
    return y_pred_test, test_prob, test_all_prob, clf_classes


def naive_bayes(X_train, y_train, X_test):
    # classifier
    clf = BernoulliNB()
    clf.fit(X_train, y_train)
    train_prob = np.amax(clf.predict_proba(X_train), axis=1)
    test_prob = np.amax(clf.predict_proba(X_test), axis=1)
    y_pred_train = clf.predict(X_train)
    y_pred_test = clf.predict(X_test)
    clf_classes = clf.classes_
    # print("classes:", classes)
    test_all_prob = clf.predict_proba(X_test)
    return y_pred_train, y_pred_test, train_prob, test_prob, test_all_prob, clf_classes


def logistic_regression(X_train, y_train, X_test):
    clf = LogisticRegression(random_state=1989, max_iter=1000).fit(X_train, y_train)
    y_pred_train = clf.predict(X_train)
    y_pred_test = clf.predict(X_test)
    train_prob = np.amax(clf.predict_proba(X_train), axis=1)
    test_prob = np.amax(clf.predict_proba(X_test), axis=1)
    clf_classes = clf.classes_
    # print("classes:", classes)
    test_all_prob = clf.predict_proba(X_test)
    return y_pred_train, y_pred_test, train_prob, test_prob, test_all_prob, clf_classes


def decision_tree(X_train, y_train, X_test):
    dt = DecisionTreeClassifier(max_depth=4, random_state=1989).fit(X_train, y_train)  # ?????
    y_pred_train = dt.predict(X_train)
    y_pred_test = dt.predict(X_test)
    train_prob = np.amax(dt.predict_proba(X_train), axis=1)
    test_prob = np.amax(dt.predict_proba(X_test), axis=1)
    smooth_train_prob = smoothing(train_prob)
    smooth_test_prob = smoothing(test_prob)
    test_all_prob = dt.predict_proba(X_test)
    # smooth_test_all_prob = smooth(test_all_prob)
    clf_classes = dt.classes_
    # print("classes:", classes)
    return y_pred_train, y_pred_test, smooth_train_prob, smooth_test_prob, test_all_prob, clf_classes


def random_forest(X_train, y_train, X_test):
    rf = RandomForestClassifier(random_state=1989).fit(X_train, y_train)
    y_pred_train = rf.predict(X_train)
    y_pred_test = rf.predict(X_test)
    train_prob = np.amax(rf.predict_proba(X_train), axis=1)
    test_prob = np.amax(rf.predict_proba(X_test), axis=1)
    smooth_train_prob = smoothing(train_prob)
    smooth_test_prob = smoothing(test_prob)
    test_all_prob = rf.predict_proba(X_test)
    smooth_test_all_prob = smoothing(test_all_prob)
    clf_classes = rf.classes_
    # print("classes:", classes)
    # print(test_all_prob.shape,smooth_test_all_prob.shape)
    return y_pred_train, y_pred_test, smooth_train_prob, smooth_test_prob, smooth_test_all_prob, clf_classes


def svm(X_train, y_train, X_test):
    clf = SVC(random_state=1989, probability=True).fit(X_train, y_train)
    y_pred_train = clf.predict(X_train)
    y_pred_test = clf.predict(X_test)
    train_prob = np.amax(clf.predict_proba(X_train), axis=1)
    test_prob = np.amax(clf.predict_proba(X_test), axis=1)
    clf_classes = clf.classes_
    # print("classes:", classes)
    test_all_prob = clf.predict_proba(X_test)
    # y_pred_all = clf.predict_proba(X_train)
    return y_pred_train, y_pred_test, train_prob, test_prob, test_all_prob, clf_classes

#
# """
# ANN
# """
# import torch
# import pandas as pd
# from torch import nn
# import torch.utils.data as data_utils
# import torch.optim as optim
# import torch.nn.functional as F
# import seaborn as sns
# import matplotlib.pyplot as plt
#
#
# def train_process(model,optimizer,train_loader):
#     # train
#     model.train()  # set train mode
#     loss_total = 0.0  # record loss for each epoch
#     acc = 0.0  # record accuracy for each epoch
#     for index, train_data in enumerate(train_loader, 1):  # for each batch
#         optimizer.zero_grad()  # set zero gradients
#         features, label = train_data  # get features and labels
#         # print("train:",features)
#         # print("label: ",features.size(0))
#         # features = features.view(features.size(0), -1)
#         # print('size',features.size())# flatten inputs
#         out = model(features)  # calculate model output
#         # print("label:",label)
#         # print(out.shape)
#         # criterion = nn.CrossEntropyLoss()
#         loss = F.cross_entropy(out, label)  # calculate loss in each batch
#         loss_total += loss.item()  # calculate loss in each epoch
#         _, pred = torch.max(out, 1)  # calculate prediction,maximum 1
#         acc += (pred == label).float().mean()  # calculate accuracy
#         loss.backward()  # back propagation
#         optimizer.step()  # update weights
#     print(f'Train Loss: {loss_total / index:.6f}, Acc: {acc / index:.6f}')  # print process
#
# def test_process(model,test_loader,out_dim):
#     # test
#     model.eval()  # test mode
#     loss_total = 0.0  # record loss
#     acc = 0.0  # record accuracy
#     y_test_pred = np.empty(0)
#     test_prob = np.empty((0,out_dim))
#     # first = True
#     test_all_prob = np.empty((0,out_dim))
#     for test in test_loader:  # get data from test_loader
#         features, label = test  # get features and labels from test loader
#         # features = features.view(features.size(0), -1)  # flatten features
#         with torch.no_grad():
#             out = model(features)  # calculate output
#             # if first:
#             #     test_all_prob = out.numpy()
#             #     first = False
#             # probs = F.softmax(out, 1)  # probs: size([batch_size,out_dim])
#             # else:
#             test_all_prob = np.concatenate([test_all_prob,out.numpy()])
#                       #  append ([batch size, out_dim]) into test_all_prob
#             loss = F.cross_entropy(out, label)  # calculate loss for each batch
#         loss_total += loss.item()  # calculate loss for each epoch
#         max_prob, pos = torch.max(out, 1)  # maximum prob, position
#         # print('pos', pos.numpy())
#         y_test_pred = np.concatenate([y_test_pred,pos.numpy()],axis=None)
#         test_prob = np.concatenate([test_prob,max_prob.numpy()],axis=None)
#         acc += (pos == label).float().mean()  # calculate accuracy
#     print(f'Test Loss: {loss_total / len(test_loader):.6f}, Acc: {acc / len(test_loader):.6f}\n')  # print process
#     return y_test_pred, test_prob, test_all_prob
#
#
# '''requirements:labels are numeric and start from 0, all datas are numeric '''
# def ann(X_train,y_train, X_test, y_test):
#     # check
#     # print("y-train:\n",pd.Series(y_train).value_counts())
#     # print("\ny_test:\n",pd.Series(y_test).value_counts())
#
#
#     X_train_tensor = torch.Tensor(X_train.values).float()
#     Y_train_tensor = torch.Tensor(y_train).long()
#     X_test_tensor = torch.Tensor(X_test.values).float()
#     Y_test_tensor = torch.Tensor(y_test).long()
#
#     # DataLoader
#     train = data_utils.TensorDataset(X_train_tensor, Y_train_tensor)
#     train_loader = data_utils.DataLoader(train, batch_size=10)
#     test = data_utils.TensorDataset(X_test_tensor, Y_test_tensor)
#     test_loader = data_utils.DataLoader(test, batch_size=10)
#
#     # hyper parameters on model
#     learning_rate = 2e-3
#     epochs = 5
#
#     # built model
#     # num of neurons
#     in_dim = 1*X_train.shape[1]
#     print("in_dim: ",in_dim)  # input layer
#     h1 = int(math.sqrt(in_dim))  # hidden layer (take the square root of input dimension)
#     classes = pd.unique(y_train).shape[0]
#     # print("classes: ",classes)# No. of classes
#     out_dim = classes  # output layer
#
#     # # record history to plot
#     # train_loss = []  # training loss
#     # test_loss = []  # testing loss
#     # train_acc = []  # training accuracy
#     # test_acc = []  # testing accuracy
#
#     # feed-forward  nn
#     class nn_net(nn.Module):
#         def __init__(self, in_dim, h1, out_dim, classes):  # define a model
#             super(nn_net, self).__init__()  # inherit nn.Module
#             self.linear1 = nn.Linear(in_dim, h1)  # input->hidden1
#             self.relu1 = nn.ReLU(True)  # relu
#             # self.linear2 = nn.Linear(h1, h2)  # hidden1>hidden2
#             # self.relu2 = nn.ReLU(True)  # relu
#             self.linear2 = nn.Linear(h1, out_dim)
#             self.softmax = nn.Softmax(dim=1)
#
#         def forward(self, x):  # feed-forward method
#             x = self.linear1(x)  # input->hidden1
#             x = self.relu1(x)  # relu
#             # x = self.linear2(x)  # hidden1>hidden2
#             # x = self.relu2(x)  # relu
#             x = self.linear2(x)
#             x = self.softmax(x)
#             return x
#
#     model = nn_net(in_dim, h1, out_dim, classes)  # built a model
#     optimizer = optim.Adam(model.parameters(), lr=learning_rate)  # set an optimizer
#
#     for epoch in range(1, epochs + 1):  # for every epoch
#         print("Epoch:", epoch)  # print epoch index
#         # train(train_loader,model,optimizer)  # call out training
#
#         train_process(model,optimizer,train_loader)
#         y_test_pred, test_prob, test_all_prob = test_process(model,test_loader,out_dim)
#
#         # train_loss.append(loss_total / index)  # record loss each epoch
#         # train_acc.append(float(acc / index))  # record accuracy each epoch
#
#         # test_loss.append(loss_total / len(test_loader))  # record loss each epoch
#         # test_acc.append(float(acc / len(test_loader)))  # record accuracy each epoch
#         # test(test_loader,model)  # call out testing
#
#     # y_test_pred_values = pd.Series(y_test_pred).value_counts()
#     # y_test_values = pd.Series(y_pred_test).value_counts()
#     # print("y_pred:",y_test_pred_values)
#     y_test_pred_array = np.array(y_test_pred)
#     # print(y_test_pred_array.shape)
#     clf_classes = list(np.arange(0,out_dim,1))
#     print(test_prob)
#     sm_test_prob = smoothing(test_prob)
#     # print("y_test_pred_array",y_test_pred_array)
#     return y_test_pred_array, sm_test_prob,test_all_prob,clf_classes

# plot
# sns.set()
# fig = plt.figure(figsize=(15, 15))
# ax1 = fig.add_subplot(211)
# # convert list into df
# df1 = pd.DataFrame({'train_loss': train_loss, 'test_loss': test_loss})
# ax1 = sns.lineplot(data=df1)
# ax1.set_xlabel("epoches")
# ax1.set_ylabel("loss")
# plt.title("Loss Change on Feed Forward NN Model")
# ax2 = fig.add_subplot(212)
# df2 = pd.DataFrame({'train_acc': train_acc, 'test_acc': test_acc})
# ax2 = sns.lineplot(data=df2)
# plt.title("Accuracy Change on Feed Forward NN Model")
# ax2.set_xlabel("epoches")
# ax2.set_ylabel("accuracy")
# plt.show()
