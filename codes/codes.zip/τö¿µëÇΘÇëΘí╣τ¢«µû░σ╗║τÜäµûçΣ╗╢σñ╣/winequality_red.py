import warnings
warnings.filterwarnings('ignore')
from implementation.classifiers import *
from implementation.main_process import main
"""
    winequality-red dataset from UCI Respositry
    Shape: (1599,11) 
    classes: quality: [3, 4, 5, 6, 7, 8]
5    681
6    638
7    199
4     53
8     18
3     10
    
"""


def preprocessing_df():
    df = pd.read_csv("./datasets/winequality-red.csv", sep=';')
    # remove blanks
    df.dropna()
    # remove unknown
    for i in range(df.shape[1]): df = df[~df.iloc[:, i].isin([" ?"])]
    return df


# preparations
t = 10
sample_sizes = [500,1000,1500]
df = preprocessing_df()


# call for test process
results = main(df,sample_sizes,t)